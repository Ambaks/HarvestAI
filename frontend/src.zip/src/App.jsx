import React from "react";
import { Routes, Route } from "react-router-dom";
import Homepage from "./pages/Homepage";
import Login from "./pages/Login";
import AdminDash from "./pages/AdminDash";
import PrivateRoute from "./utils/PrivateRoute";


const App = () => {
  return (
    <Routes>
      <Route path="/" element={<Homepage />} />
      <Route path="/login" element={<Login />} />
      <Route
          path="/dashboard"
          element={
            <PrivateRoute>
                <AdminDash />
            </PrivateRoute>
          }
        />
    </Routes>
  );
};

export default App;
