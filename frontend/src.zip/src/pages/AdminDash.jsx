import React, { useEffect, useContext } from "react";
import axios from "axios";             
import { UserContext } from "../context/UserContext";

const AdminDash = () => {
  const { user, setUser } = useContext(UserContext);

  useEffect(() => {
    const fetchUserData = async () => {
      // 2. Ensure user context is not null before fetching
      if (!user) {
        console.warn("User is not available yet.");
        return;
      }

      try {
        // 3. Use axios to fetch user data
        const response = await axios.get(`/users/${user.email}`, {
          withCredentials: true, // needed for cookie-based auth
        });
        // 4. Update the user context with new data
        setUser(response.data);
      } catch (error) {
        console.error("Error fetching user data:", error.response?.data);
        // Optionally clear user or handle error
        setUser(null);
      }
    };

    fetchUserData();
  }, [user, setUser]);

  if (!user) {
    return <div>Loading user or not logged in...</div>;
  }

  return (
    <div>
      <h1>User Profile</h1>
      <p>Email: {user.email}</p>
      <p>First Name: {user.first_name}</p>
      <p>Last Name: {user.last_name}</p>
    </div>
  );
};

export default AdminDash;
