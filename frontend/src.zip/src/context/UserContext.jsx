import React, { createContext, useState, useEffect } from "react";
import axios from "axios";

export const UserContext = createContext();

export const UserProvider = ({ children }) => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        if (!user?.email) return;

        // Fetch user data from /users/{email}
        const response = await axios.get(`/users/${user.email}`, {
          withCredentials: true, // Include cookies
        });

        setUser(response.data);
      } catch (error) {
        console.error("Failed to fetch user data:", error.response?.data);
        setUser(null);
      }
    };

    fetchUserData();
  }, [user?.email]);

  return (
    <UserContext.Provider value={{ user, setUser }}>
      {children}
    </UserContext.Provider>
  );
};
