import axios from "axios";

export const login = async (email, password) => {
  const response = await axios.post(
    "http://localhost:8000/auth/login", 
    { email, password }, 
    { withCredentials: true } // Ensures cookies are handled automatically.
  );

  return response.data; // Now expect { user_info } (backend sets cookie)
};


export const register = async (firstName, lastName, email, password) => {
    const response = await axios.post("http://localhost:8000/auth/register", {
      first_name: firstName,
      last_name: lastName,
      email,
      password, // Send as JSON
    });
  
    return response.data; // Expect { message: "User registered successfully" }
  };