from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy.orm import Session
from fastapi.security import OAuth2PasswordRequestForm
from services.auth import verify_password, create_access_token, verify_access_token
from crud.user import read_user, create_user
from schemas.user import Token
from api.dependencies import get_db
from schemas.auth import LoginRequest, RegisterRequest
from models.user import User
from schemas.user import UserBase

router = APIRouter()

@router.post("/auth/register", response_model=Token)
def register(user: RegisterRequest, db: Session = Depends(get_db)):
    existing_user = read_user(db, user.email)
    if existing_user:
        raise HTTPException(status_code=400, detail="Username already exists")
    create_user(db, user)
    access_token = create_access_token(data={"sub": user.email})
    return {"access_token": access_token, "token_type": "bearer"}

"""
@router.post("/auth/login", response_model=Token)
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = get_user_by_username(db, form_data.username)
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Invalid credentials")
    access_token = create_access_token(data={"sub": user.username})
    return {"access_token": access_token, "token_type": "bearer"}
"""


@router.post("/auth/login")
def login(request: LoginRequest, response: Response, db: Session = Depends(get_db)):
    # Use email to fetch user
    user = db.query(User).filter(User.email == request.email).first()
    if not user or not verify_password(request.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    # Generate JWT token
    access_token = create_access_token(data={"sub": user.email})
    
    response.set_cookie(
        key="access_token",
        value=access_token,
        httponly=True,
        secure=False,  # Set to True in production for HTTPS
        samesite="Lax"
    )
    return {"message": "Login successful", "user_email": user.email}

@router.get("/auth/user", response_model=UserBase)
def read_user(user: User = Depends(verify_access_token)):
    """
    Returns the current user data by reading the JWT from an HttpOnly cookie.
    The cookie should be set by the login endpoint after authentication.
    """
    return user