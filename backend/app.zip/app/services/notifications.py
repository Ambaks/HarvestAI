# Handle notifications

def send_notification(user_id: int, message: str):
    # Placeholder for notifications logic
    return {"status": "sent", "user_id": user_id}