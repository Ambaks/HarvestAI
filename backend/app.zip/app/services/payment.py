# Handle payment logic

def process_payment(transaction_id: int):
    # Placeholder for payment processing logic
    return {"status": "success", "transaction_id": transaction_id}